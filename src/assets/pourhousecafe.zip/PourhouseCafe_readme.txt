Pourhouse Cafe:

-Clean website with muted colors
-Emphasize missions and non profit missions
-Emphasize donations that fund PHC
-Updated pictures of the café 


